import{c as i,g as y}from"./index-5nriPR9m.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=i("Bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=i("Calculator",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",key:"1nb95v"}],["line",{x1:"8",x2:"16",y1:"6",y2:"6",key:"x4nwl0"}],["line",{x1:"16",x2:"16",y1:"14",y2:"18",key:"wjye3r"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M8 14h.01",key:"6423bh"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M8 18h.01",key:"lrp35t"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=i("Minimize2",[["polyline",{points:"4 14 10 14 10 20",key:"11kfnr"}],["polyline",{points:"20 10 14 10 14 4",key:"rlmsce"}],["line",{x1:"14",x2:"21",y1:"10",y2:"3",key:"o5lafz"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]]);function s(r){try{return JSON.parse(r)}catch{return null}}async function c(r){if(r.status!==429)return null;const n=r.headers.get("retry-after"),a=n?Number(n):void 0,e=await r.text().catch(()=>""),t=typeof e=="string"&&e?s(e):null,o=t&&typeof t=="object"?{error:typeof t.error=="string"?t.error:void 0,action:typeof t.action=="string"?t.action:void 0,tier:typeof t.tier=="string"?t.tier:void 0,retryAfter:typeof t.retryAfter=="number"?t.retryAfter:void 0}:{};return{payload:o,retryAfterSeconds:Number.isFinite(a)?a:typeof o.retryAfter=="number"?o.retryAfter:void 0}}async function f(r){const n=await c(r);if(!n)return!1;const a=n.retryAfterSeconds,e=n.payload.action;return y({title:"Слишком много запросов",description:a?e?`Действие: ${e}. Попробуйте снова через ${a} сек.`:`Попробуйте снова через ${a} сек.`:e?`Действие: ${e}. Попробуйте чуть позже.`:"Попробуйте чуть позже."}),!0}export{p as B,d as C,l as M,f as m};
