import{r as t}from"./index-5nriPR9m.js";var e=t.createContext(void 0);function i(r){const o=t.useContext(e);return r||o||"ltr"}export{i as u};
