const o="/assets/logo-t2bzs3k9.png";export{o as l};
