function c(a,[t,n]){return Math.min(n,Math.max(t,a))}export{c};
