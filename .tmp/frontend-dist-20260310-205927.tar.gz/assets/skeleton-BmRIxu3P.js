import{j as t,K as n}from"./index-BRixZw2N.js";function m({className:e,...s}){return t.jsx("div",{className:n("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
