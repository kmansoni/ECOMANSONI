import{k as G,r as m,p as ne,j as e,a1 as J,a3 as U,B as j,b3 as se,V as re,a5 as T,T as ae,K as R,ak as oe,an as ie,a8 as ce}from"./index-BRixZw2N.js";import{S as le}from"./scroll-area-Ds1Q_q44.js";import{m as de}from"./rateLimitToast-hIKYe1Qj.js";import{C as me}from"./chart-column-CsDPC8lw.js";import{S as ue}from"./shield-check-oHA1VS5k.js";import{P as pe}from"./pen-DSQtEG4-.js";import{S as he}from"./square-BZJ148ht.js";import"./index-BdQq_4o_.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xe=G("Brain",[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}],["path",{d:"M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z",key:"ep3f8r"}],["path",{d:"M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4",key:"1p4c4q"}],["path",{d:"M17.599 6.5a3 3 0 0 0 .399-1.375",key:"tmeiqw"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}],["path",{d:"M19.938 10.5a4 4 0 0 1 .585.396",key:"1qfode"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}],["path",{d:"M19.967 17.484A4 4 0 0 1 18 18",key:"159ez6"}]]);/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fe=G("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]]),C="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxma2JnbmJqeHNrc3Bzb3dudmptIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE0NDI0NTYsImV4cCI6MjA4NzAxODQ1Nn0.WNubMc1s9TA91aT_txY850x2rWJ1ayxiTs7Rq6Do21k",be="https://lfkbgnbjxskspsownvjm.supabase.co",z=`${be}/functions/v1/aria-chat`;const ge="7CL4PqXhAe1i3Npb";const q=!!ge&&!1;console.warn("[ARIA] VITE_AI_API_KEY is set but will be IGNORED in production builds. Deploy the aria-chat Edge Function and store AI_API_KEY in Supabase Vault.");function Ee(r){var l;const s=[...r].reverse().find(d=>d.role==="user"),n=((s==null?void 0:s.content)??"").toLowerCase().trim();if(/^(привет|hello|hi |здравствуй|добрый|хай)/.test(n))return`Привет! Я **ARIA** — ИИ-ассистент платформы Mansoni.

Чем могу помочь?
- 💻 Код (Python, TypeScript, SQL и др.)
- 🔒 Безопасность кода
- 📊 Анализ данных
- ✍️ Документация и тексты

> **Для полных возможностей:** настройте \`VITE_AI_API_KEY\` в \`.env.local\` или задеплойте \`aria-chat\` Edge Function в Supabase.`;if(/кто ты|who are you|what are you/.test(n))return`Я **ARIA** (Advanced Reasoning & Intelligence Assistant) — самообучающийся ИИ-ассистент платформы Mansoni.

Архитектура: GPT-based Transformer + RAG + ReAct Agent + 3-layer Memory.

**Режим:** базовый (client-side fallback)
> Для полного режима: настройте AI backend через \`VITE_AI_API_KEY\`.`;if(/(fastapi|flask).*jwt|jwt.*(fastapi|flask)/.test(n))return`# FastAPI + JWT

\`\`\`python
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from datetime import datetime, timedelta
import os

SECRET_KEY = os.environ["JWT_SECRET"]
ALGORITHM = "HS256"

app = FastAPI()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def create_token(data: dict, expires: timedelta = timedelta(minutes=30)):
    return jwt.encode({**data, "exp": datetime.utcnow() + expires}, SECRET_KEY, ALGORITHM)

@app.get("/protected")
async def protected(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return {"user": payload.get("sub")}
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
\`\`\`

\`\`\`bash
pip install fastapi python-jose[cryptography] passlib[bcrypt]
\`\`\``;if(/python.*list|список.*python|list comprehension/.test(n))return`# Списки в Python

\`\`\`python
nums = [1, 2, 3, 4, 5]
squares = [x**2 for x in nums]          # [1, 4, 9, 16, 25]
evens = [x for x in nums if x % 2 == 0] # [2, 4]

# Сортировка
nums.sort()                              # На месте
sorted_desc = sorted(nums, reverse=True) # Новый список

# Срезы
first_three = nums[:3]
last_two = nums[-2:]
reversed_list = nums[::-1]

print(len(nums), sum(nums), min(nums), max(nums))
\`\`\``;if(/sql|database|запрос/.test(n))return`# SQL — основные паттерны

\`\`\`sql
-- JOIN + агрегация
SELECT u.name, COUNT(o.id) as orders
FROM users u
LEFT JOIN orders o ON u.id = o.user_id
WHERE u.active = true
GROUP BY u.id, u.name
HAVING COUNT(o.id) > 0
ORDER BY orders DESC;

-- Индексы
CREATE INDEX CONCURRENTLY idx_orders_user ON orders(user_id);

-- CTE
WITH latest AS (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY created_at DESC) rn
  FROM orders
)
SELECT * FROM latest WHERE rn = 1;
\`\`\``;if(/безопасност|security|xss|sql.?inject|уязвим/.test(n))return`# Безопасность кода

## SQL Injection
\`\`\`python
# ❌ Уязвимо
query = f"SELECT * FROM users WHERE id = {user_id}"

# ✅ Безопасно
cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
\`\`\`

## XSS
\`\`\`typescript
// ❌ Уязвимо
element.innerHTML = userInput;

// ✅ Безопасно
element.textContent = userInput;
\`\`\`

## Secrets
\`\`\`python
# ❌ Никогда
API_KEY = "sk-hardcoded"

# ✅ Всегда
API_KEY = os.environ["API_KEY"]
\`\`\``;if(/typescript|react|tsx|компонент/.test(n))return`# React + TypeScript хук

\`\`\`tsx
import { useState, useCallback } from 'react';

function useCounter(initial = 0) {
  const [count, setCount] = useState(initial);
  const increment = useCallback(() => setCount(c => c + 1), []);
  const decrement = useCallback(() => setCount(c => c - 1), []);
  const reset = useCallback(() => setCount(initial), [initial]);
  return { count, increment, decrement, reset };
}

// Использование
export function Counter() {
  const { count, increment, decrement, reset } = useCounter(0);
  return (
    <div className="flex gap-2 items-center">
      <button onClick={decrement}>−</button>
      <span className="font-bold">{count}</span>
      <button onClick={increment}>+</button>
      <button onClick={reset} className="text-xs">Reset</button>
    </div>
  );
}
\`\`\``;if(/docker|контейнер|dockerfile/.test(n))return`# Dockerfile (Python)

\`\`\`dockerfile
FROM python:3.12-slim AS builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir --user -r requirements.txt

FROM python:3.12-slim
WORKDIR /app
RUN useradd --create-home appuser && chown -R appuser /app
USER appuser
COPY --from=builder /root/.local /home/appuser/.local
COPY . .
ENV PATH=/home/appuser/.local/bin:$PATH PYTHONUNBUFFERED=1
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
\`\`\`

\`\`\`bash
docker build -t myapp .
docker compose up -d
docker logs myapp -f
\`\`\``;const p=((l=s==null?void 0:s.content)==null?void 0:l.slice(0,150))??"";return`Я **ARIA** — ИИ-ассистент Mansoni. Вы написали: *"${p}${p.length>=150?"...":""}"*

Попробуйте спросить о:
- Коде и архитектуре
- Безопасности
- SQL и базах данных
- Docker и DevOps
- React / TypeScript

> **Режим:** client-side fallback (без сервера)
> Для полного AI: настройте \`VITE_AI_API_KEY\` в \`.env.local\``}function ye(r){const s=new TextEncoder,n=r.split(" "),p=`chatcmpl-local-${Date.now()}`;return new ReadableStream({async start(l){for(let o=0;o<n.length;o+=3){const u=n.slice(o,o+3).join(" "),N=o+3<n.length?u+" ":u,y=JSON.stringify({id:p,object:"chat.completion.chunk",created:Math.floor(Date.now()/1e3),model:"aria-local",choices:[{index:0,delta:{content:N},finish_reason:null}]});l.enqueue(s.encode(`data: ${y}

`)),await new Promise(h=>setTimeout(h,20))}const a=JSON.stringify({id:p,object:"chat.completion.chunk",created:Math.floor(Date.now()/1e3),model:"aria-local",choices:[{index:0,delta:{},finish_reason:"stop"}]});l.enqueue(s.encode(`data: ${a}

`)),l.enqueue(s.encode(`data: [DONE]

`)),l.close()}})}const Ae=[{icon:fe,text:"Напиши REST API на FastAPI с JWT-аутентификацией",color:"text-violet-500"},{icon:me,text:"Помоги с анализом данных: pandas + визуализация",color:"text-cyan-500"},{icon:ue,text:"Проверь этот код на уязвимости безопасности",color:"text-emerald-500"},{icon:pe,text:"Напиши техническое ТЗ для мобильного приложения",color:"text-rose-500"},{icon:xe,text:"Объясни как работают трансформеры (Attention)",color:"text-amber-500"}];function V(){return`${Date.now()}-${Math.random().toString(36).slice(2,9)}`}function we(r){return r.toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"})}function Ne(r){let s=r.replace(/```(\w*)\n?([\s\S]*?)```/g,(a,o,u)=>`<pre class="bg-black/20 rounded-lg p-3 my-2 overflow-x-auto text-xs font-mono"><code class="language-${O(o)}">${O(u.trim())}</code></pre>`).replace(/`([^`]+)`/g,(a,o)=>`<code class="bg-black/20 rounded px-1 py-0.5 font-mono text-xs">${O(o)}</code>`);const n=[];let d=s.replace(/<pre[\s\S]*?<\/pre>|<code[\s\S]*?<\/code>/g,a=>(n.push(a),`__CODE_TOKEN_${n.length-1}__`)).replace(/[&<>"']/g,a=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&#34;","'":"&#39;"})[a]??a).replace(/__CODE_TOKEN_(\d+)__/g,(a,o)=>n[Number(o)]);return d=d.replace(/\*\*([^*]+)\*\*/g,"<strong>$1</strong>").replace(/\*([^*]+)\*/g,"<em>$1</em>").replace(/^### (.+)$/gm,'<h3 class="font-semibold text-sm mt-3 mb-1">$1</h3>').replace(/^## (.+)$/gm,'<h2 class="font-semibold text-base mt-4 mb-1">$1</h2>').replace(/^# (.+)$/gm,'<h1 class="font-bold text-lg mt-4 mb-2">$1</h1>').replace(/^---$/gm,'<hr class="border-border/40 my-3" />').replace(/^\d+\. (.+)$/gm,'<li class="ml-4 list-decimal">$1</li>').replace(/^[-*] (.+)$/gm,'<li class="ml-4 list-disc">$1</li>').replace(/^\|(.+)\|$/gm,(a,o)=>{const u=o.split("|").map(h=>h.trim()).filter(Boolean);if(u.every(h=>/^[-:]+$/.test(h)))return"";const y="td";return`<tr>${u.map(h=>`<${y} class="border border-border/40 px-2 py-1 text-xs">${h}</${y}>`).join("")}</tr>`}).replace(/\n/g,"<br />"),d}function O(r){const s={"&":"&","<":"<",">":">",'"':"&#34;","'":"'"};return r.replace(/[&<>"']/g,n=>s[n]??n)}async function*W(r){const s=new TextDecoder;let n="";for(;;){const{done:p,value:l}=await r.read();if(p)break;n+=s.decode(l,{stream:!0});let d;for(;(d=n.indexOf(`
`))!==-1;){let a=n.slice(0,d);if(n=n.slice(d+1),a.endsWith("\r")&&(a=a.slice(0,-1)),a.startsWith(":")||a.trim()===""||!a.startsWith("data: "))continue;const o=a.slice(6).trim();if(o==="[DONE]")return;yield o}}}function Ce(){const[r,s]=m.useState([]),[n,p]=m.useState(""),[l,d]=m.useState(!1),[a,o]=m.useState(!1),u=m.useRef(null),N=m.useRef(null),y=m.useRef(null),h=m.useCallback(()=>{var t;(t=N.current)==null||t.scrollIntoView({behavior:"smooth"})},[]);m.useEffect(()=>{r.length>0&&h()},[r,h]);const X=m.useCallback(t=>{const x=t.currentTarget;o(x.scrollHeight-x.scrollTop-x.clientHeight>120)},[]),S=m.useCallback(async t=>{var M,D,L,$,Y,B,F;const x=t.trim();if(!x||l)return;const k={id:V(),role:"user",content:x,timestamp:new Date},g=V();s(b=>[...b,k,{id:g,role:"assistant",content:"",timestamp:new Date,streaming:!0}]),p(""),d(!0);const P=new AbortController;u.current=P;try{const b=[...r,k].map(c=>({role:c.role,content:c.content}));let i;if(!q)if(z&&C)i=await fetch(z,{method:"POST",headers:{"Content-Type":"application/json",apikey:C,Authorization:`Bearer ${C}`},body:JSON.stringify({messages:b}),signal:P.signal});else throw new TypeError("Failed to fetch: no backend configured");if(!i.ok){if(i.status===404&&!q)throw new Error("aria-chat: функция не задеплоена. Добавьте VITE_AI_API_KEY в .env.local или задеплойте edge function.");if(await de(i.clone())){s(A=>A.filter(w=>w.id!==g));return}const c=await i.json().catch(()=>({error:"Ошибка сервера"}));throw new Error(c.error??`HTTP ${i.status}`)}if(!i.body)throw new Error("Empty response body");const H=i.body.getReader();let E="";for await(const c of W(H))try{const w=(L=(D=(M=JSON.parse(c).choices)==null?void 0:M[0])==null?void 0:D.delta)==null?void 0:L.content;w&&(E+=w,s(I=>I.map(f=>f.id===g?{...f,content:E,streaming:!0}:f)))}catch{}s(c=>c.map(A=>A.id===g?{...A,streaming:!1}:A))}catch(b){if(b.name==="AbortError"){s(E=>E.map(c=>c.id===g?{...c,streaming:!1}:c));return}console.error("[AIAssistantPage] stream error:",b);const i=b instanceof Error?b.message:"";if(b instanceof TypeError&&i.includes("fetch")||i.includes("Failed to fetch")||i.includes("NetworkError")||i.includes("не задеплоена")||i.includes("503")||i.includes("502")||i.includes("AI service is not configured")){const E=[...r,k].map(f=>({role:f.role,content:f.content})),c=Ee(E),w=ye(c).getReader();let I="";try{for await(const f of W(w))try{const K=(B=(Y=($=JSON.parse(f).choices)==null?void 0:$[0])==null?void 0:Y.delta)==null?void 0:B.content;K&&(I+=K,s(te=>te.map(v=>v.id===g?{...v,content:I,streaming:!0}:v)))}catch{}}catch{}s(f=>f.map(_=>_.id===g?{..._,streaming:!1}:_));return}ne.error(i||"Ошибка соединения с ARIA"),s(E=>E.filter(c=>!(c.id===g&&c.content==="")))}finally{d(!1),u.current=null,(F=y.current)==null||F.focus()}},[l,r]),Q=m.useCallback(()=>{var t;(t=u.current)==null||t.abort()},[]),Z=m.useCallback(t=>{t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),S(n))},[n,S]),ee=m.useCallback(()=>{var t;(t=u.current)==null||t.abort(),s([]),d(!1)},[]);return e.jsxs("div",{className:"flex flex-col h-[calc(100dvh-4rem)] max-w-3xl mx-auto",children:[e.jsxs("div",{className:"flex items-center justify-between px-4 py-3 border-b border-border/60 bg-background/80 backdrop-blur-sm shrink-0",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsxs("div",{className:"relative",children:[e.jsx(J,{className:"w-9 h-9 bg-gradient-to-br from-violet-500 to-cyan-500",children:e.jsx(U,{className:"bg-transparent text-white",children:e.jsx(j,{className:"w-5 h-5"})})}),e.jsx("span",{className:"absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-background"})]}),e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"font-semibold text-sm",children:"ARIA"}),e.jsxs(se,{variant:"secondary",className:"text-[10px] px-1.5 py-0 h-4",children:[e.jsx(re,{className:"w-2.5 h-2.5 mr-0.5"}),"AI"]})]}),e.jsx("p",{className:"text-[11px] text-muted-foreground leading-none mt-0.5",children:"Мультимодальный ИИ-ассистент · Gemini 2.5 Pro"})]})]}),r.length>0&&e.jsx(T,{variant:"ghost",size:"icon",className:"h-8 w-8 text-muted-foreground hover:text-destructive",onClick:ee,title:"Очистить историю",children:e.jsx(ae,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"relative flex-1 overflow-hidden",children:[e.jsx(le,{className:"h-full",onScrollCapture:X,children:e.jsxs("div",{className:"px-4 py-4 space-y-4",children:[r.length===0&&e.jsxs("div",{className:"mx-1 mb-4 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-400 space-y-2",children:[e.jsx("p",{className:"font-semibold",children:"⚙️ Требуется настройка"}),e.jsx("p",{children:"ARIA не подключена к AI-бэкенду. Варианты:"}),e.jsxs("ol",{className:"list-decimal ml-4 space-y-1",children:[e.jsxs("li",{children:[e.jsx("b",{children:"Быстро:"})," Добавьте в ",e.jsx("code",{className:"bg-black/20 px-1 rounded",children:".env.local"}),":",e.jsx("br",{}),"VITE_AI_API_KEY=<AI_API_KEY from Supabase Vault>",e.jsx("br",{}),e.jsx("span",{className:"text-amber-300/70",children:"Взять из: Supabase Dashboard → Settings → Vault → AI_API_KEY"})]}),e.jsxs("li",{children:[e.jsx("b",{children:"Прода:"})," Push в ветку ",e.jsx("code",{className:"bg-black/20 px-1 rounded",children:"main"})," — GitHub Actions задеплоит ",e.jsx("code",{className:"bg-black/20 px-1 rounded",children:"aria-chat"})," автоматически."]})]})]}),r.length===0&&e.jsxs("div",{className:"flex flex-col items-center justify-center py-8 text-center gap-5",children:[e.jsx("div",{className:"w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500/20 to-cyan-500/20 flex items-center justify-center",children:e.jsx(j,{className:"w-8 h-8 text-violet-500"})}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-lg font-semibold mb-1",children:"Привет! Я ARIA"}),e.jsx("p",{className:"text-sm text-muted-foreground max-w-xs",children:"Мультимодальный ИИ-ассистент на базе Gemini 2.5 Pro. Помогу с кодом, данными, текстами и любыми вопросами."})]}),e.jsx("div",{className:"grid grid-cols-1 gap-2 w-full max-w-sm",children:Ae.map(({icon:t,text:x,color:k})=>e.jsxs("button",{onClick:()=>void S(x),disabled:l,className:"flex items-center gap-2.5 text-left text-sm px-3 py-2.5 rounded-xl border border-border/60 hover:border-violet-500/50 hover:bg-violet-500/5 transition-colors text-muted-foreground hover:text-foreground disabled:opacity-50 disabled:cursor-not-allowed",children:[e.jsx(t,{className:R("w-4 h-4 shrink-0",k)}),e.jsx("span",{children:x})]},x))})]}),r.map(t=>e.jsxs("div",{className:R("flex gap-3",t.role==="user"?"flex-row-reverse":"flex-row"),children:[t.role==="assistant"&&e.jsx(J,{className:"w-7 h-7 shrink-0 mt-0.5 bg-gradient-to-br from-violet-500 to-cyan-500",children:e.jsx(U,{className:"bg-transparent text-white text-xs",children:e.jsx(j,{className:"w-3.5 h-3.5"})})}),e.jsxs("div",{className:R("max-w-[85%] rounded-2xl px-4 py-2.5 text-sm",t.role==="user"?"bg-violet-600 text-white rounded-tr-sm":"bg-muted text-foreground rounded-tl-sm"),children:[t.role==="assistant"?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"prose prose-sm prose-invert max-w-none leading-relaxed [&_pre]:my-2 [&_code]:text-xs [&_li]:my-0.5 [&_h1]:mt-3 [&_h2]:mt-2 [&_h3]:mt-2 [&_table]:w-full [&_table]:border-collapse [&_table]:text-xs [&_td]:border [&_td]:border-border/40 [&_td]:px-2 [&_td]:py-1",dangerouslySetInnerHTML:{__html:t.content?Ne(t.content):t.streaming?'<span class="animate-pulse">▊</span>':""}}),t.streaming&&t.content&&e.jsx("span",{className:"inline-block w-1.5 h-3.5 bg-current ml-0.5 animate-pulse"})]}):e.jsx("p",{className:"whitespace-pre-wrap leading-relaxed",children:t.content}),e.jsx("p",{className:R("text-[10px] mt-1 text-right",t.role==="user"?"text-violet-200/70":"text-muted-foreground"),children:we(t.timestamp)})]})]},t.id)),e.jsx("div",{ref:N})]})}),a&&e.jsx("button",{onClick:h,className:"absolute bottom-4 right-4 w-8 h-8 rounded-full bg-background border border-border shadow-md flex items-center justify-center hover:bg-muted transition-colors z-10",children:e.jsx(oe,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"px-4 py-3 border-t border-border/60 bg-background/80 backdrop-blur-sm shrink-0",children:[e.jsxs("div",{className:"flex gap-2 items-end",children:[e.jsx(ie,{ref:y,value:n,onChange:t=>p(t.target.value),onKeyDown:Z,placeholder:"Напишите сообщение… (Enter — отправить, Shift+Enter — новая строка)",className:"resize-none min-h-[44px] max-h-[160px] text-sm",rows:1,disabled:l}),l?e.jsx(T,{size:"icon",variant:"destructive",className:"h-11 w-11 shrink-0",onClick:Q,title:"Остановить генерацию",children:e.jsx(he,{className:"w-4 h-4"})}):e.jsx(T,{size:"icon",className:"h-11 w-11 shrink-0 bg-violet-600 hover:bg-violet-700",onClick:()=>void S(n),disabled:!n.trim(),title:"Отправить (Enter)",children:e.jsx(ce,{className:"w-4 h-4"})})]}),e.jsx("p",{className:"text-[10px] text-muted-foreground mt-1.5 text-center",children:"ARIA может ошибаться. Проверяйте важную информацию в авторитетных источниках."})]})]})}export{Ce as AIAssistantPage,Ce as default};
